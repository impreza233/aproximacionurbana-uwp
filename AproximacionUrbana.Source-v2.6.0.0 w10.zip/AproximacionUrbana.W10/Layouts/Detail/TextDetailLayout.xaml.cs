namespace AproximacionUrbana.Layouts.Detail
{
    public sealed partial class TextDetailLayout : BaseDetailLayout
    {
        public TextDetailLayout()
        {
            InitializeComponent();
        }
    }
}
