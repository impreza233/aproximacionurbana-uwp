using System.Collections.ObjectModel;
using Windows.UI.Xaml;
using AppStudio.Uwp.Controls;
using AproximacionUrbana.ViewModels;

namespace AproximacionUrbana.Layouts.List
{
    public sealed partial class ListGrouped : ListLayoutBase
    {
        public ListGrouped()
        {
            this.InitializeComponent();
        }
    }
}
