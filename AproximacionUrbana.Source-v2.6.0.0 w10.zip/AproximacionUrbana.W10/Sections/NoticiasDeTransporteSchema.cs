using System;
using AppStudio.DataProviders;

namespace AproximacionUrbana.Sections
{
    /// <summary>
    /// Implementation of the NoticiasDeTransporteSchema class.
    /// </summary>
    public class NoticiasDeTransporteSchema : SchemaBase
    {

        public string title { get; set; }

        public string name { get; set; }

        public string content { get; set; }

        public string featured_image { get; set; }
    }
}
