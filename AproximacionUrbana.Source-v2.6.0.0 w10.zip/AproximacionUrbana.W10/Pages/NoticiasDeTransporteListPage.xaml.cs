//---------------------------------------------------------------------------
//
// <copyright file="NoticiasDeTransporteListPage.xaml.cs" company="Microsoft">
//    Copyright (C) 2015 by Microsoft Corporation.  All rights reserved.
// </copyright>
//
// <createdOn>6/4/2017 6:57:13 PM</createdOn>
//
//---------------------------------------------------------------------------

using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Xaml;
using AppStudio.DataProviders.RestApi;
using AproximacionUrbana.Sections;
using AproximacionUrbana.ViewModels;
using AppStudio.Uwp;

namespace AproximacionUrbana.Pages
{
    public sealed partial class NoticiasDeTransporteListPage : Page
    {
	    public ListViewModel ViewModel { get; set; }
        public NoticiasDeTransporteListPage()
        {
			ViewModel = ViewModelFactory.NewList(new NoticiasDeTransporteSection());

            this.InitializeComponent();
			commandBar.DataContext = ViewModel;
			NavigationCacheMode = NavigationCacheMode.Enabled;
        }

        protected override async void OnNavigatedTo(NavigationEventArgs e)
        {
			ShellPage.Current.ShellControl.SelectItem("4dd25fa0-cfe4-48ca-a4e1-fde16c188e41");
			ShellPage.Current.ShellControl.SetCommandBar(commandBar);
			if (e.NavigationMode == NavigationMode.New)
            {			
				await this.ViewModel.LoadDataAsync();
                this.ScrollToTop();
			}			
            base.OnNavigatedTo(e);
        }

    }
}
