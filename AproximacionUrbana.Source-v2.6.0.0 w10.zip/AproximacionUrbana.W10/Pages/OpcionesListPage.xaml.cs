//---------------------------------------------------------------------------
//
// <copyright file="OpcionesListPage.xaml.cs" company="Microsoft">
//    Copyright (C) 2015 by Microsoft Corporation.  All rights reserved.
// </copyright>
//
// <createdOn>6/4/2017 6:57:13 PM</createdOn>
//
//---------------------------------------------------------------------------

using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Xaml;
using AppStudio.DataProviders.LocalStorage;
using AppStudio.DataProviders.Menu;
using AproximacionUrbana.Sections;
using AproximacionUrbana.ViewModels;
using AppStudio.Uwp;

namespace AproximacionUrbana.Pages
{
    public sealed partial class OpcionesListPage : Page
    {
	    public ListViewModel ViewModel { get; set; }
        public OpcionesListPage()
        {
			ViewModel = ViewModelFactory.NewList(new OpcionesSection());

            this.InitializeComponent();
			commandBar.DataContext = ViewModel;
			NavigationCacheMode = NavigationCacheMode.Enabled;
        }

        protected override async void OnNavigatedTo(NavigationEventArgs e)
        {
			ShellPage.Current.ShellControl.SelectItem("29a9554f-f598-47a1-9bc3-3d4add567ac2");
			ShellPage.Current.ShellControl.SetCommandBar(commandBar);
			if (e.NavigationMode == NavigationMode.New)
            {			
				await this.ViewModel.LoadDataAsync();
                this.ScrollToTop();
			}			
            base.OnNavigatedTo(e);
        }

    }
}
