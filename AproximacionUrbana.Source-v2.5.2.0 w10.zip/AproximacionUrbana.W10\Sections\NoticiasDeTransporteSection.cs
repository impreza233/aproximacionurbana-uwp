using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using AppStudio.DataProviders;
using AppStudio.DataProviders.Core;
using AppStudio.DataProviders.RestApi;
using AppStudio.Uwp.Actions;
using AppStudio.Uwp.Commands;
using AppStudio.Uwp;
using System.Linq;

using AproximacionUrbana.Navigation;
using AproximacionUrbana.ViewModels;

namespace AproximacionUrbana.Sections
{	
	public class NoticiasDeTransporteSection : Section<NoticiasDeTransporteSchema>
    {
		private RestApiDataProvider _dataProvider;


		public NoticiasDeTransporteSection()
		{	
			_dataProvider = new RestApiDataProvider();
		}

		public override async Task<IEnumerable<NoticiasDeTransporteSchema>> GetDataAsync(SchemaBase connectedItem = null)
        {
            var config = new RestApiDataConfig
            { 
				Url = new Uri("https://public-api.wordpress.com/rest/v1.1/sites/75598411/posts/"),
				Headers = GetHeaders(),
				PaginationConfig = new MemoryPagination()
				{
					OrderBy = "title",
					OrderDirection = SortDirection.Descending
				}
			};

			return await _dataProvider.LoadDataAsync(config, MaxRecords, new NoticiasDeTransporteSchemaParser());
        }

        public override async Task<IEnumerable<NoticiasDeTransporteSchema>> GetNextPageAsync()
        {
            return await _dataProvider.LoadMoreDataAsync<NoticiasDeTransporteSchema>();
        }

        public override bool HasMorePages
        {
            get
            {
                return _dataProvider.HasMoreItems;
            }
        }

        public override ListPageConfig<NoticiasDeTransporteSchema> ListPage
        {
            get 
            {
                return new ListPageConfig<NoticiasDeTransporteSchema>
                {
                    Title = "Noticias de Transporte",

                    Page = typeof(Pages.NoticiasDeTransporteListPage),

                    LayoutBindings = (viewModel, item) =>
                    {
                        viewModel.Title = item.title.ToSafeString();
                        viewModel.SubTitle = item.name.ToSafeString();
                        viewModel.ImageUrl = ItemViewModel.LoadSafeUrl(item.featured_image.ToSafeString());

						viewModel.GroupBy = item.title.SafeType();

						viewModel.OrderBy = item.title;
                    },
					OrderType = OrderType.Ascending,
                    DetailNavigation = (item) =>
                    {
						return NavInfo.FromPage<Pages.NoticiasDeTransporteDetailPage>(true);
                    }
                };
            }
        }

        public override DetailPageConfig<NoticiasDeTransporteSchema> DetailPage
        {
            get
            {
                var bindings = new List<Action<ItemViewModel, NoticiasDeTransporteSchema>>();
                bindings.Add((viewModel, item) =>
                {
                    viewModel.PageTitle = "Detail";
                    viewModel.Title = item.title.ToSafeString();
                    viewModel.Description = item.content.ToSafeString();
                    viewModel.ImageUrl = ItemViewModel.LoadSafeUrl(item.featured_image.ToSafeString());
                    viewModel.Content = null;					
                });

                var actions = new List<ActionConfig<NoticiasDeTransporteSchema>>
                {
                };

                return new DetailPageConfig<NoticiasDeTransporteSchema>
                {
                    Title = "Noticias de Transporte",
                    LayoutBindings = bindings,
                    Actions = actions
                };
            }
        }
		
		private IDictionary<string, string> GetHeaders()
        {
			IDictionary<string, string> result = new Dictionary<string, string>();
			result["User-Agent"] ="Mozilla/5.0 (Windows NT 10.0)";
            return result;
        }
		
    }
}
