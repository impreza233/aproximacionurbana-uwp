//---------------------------------------------------------------------------
//
// <copyright file="NoticiasDeUrbanismoListPage.xaml.cs" company="Microsoft">
//    Copyright (C) 2015 by Microsoft Corporation.  All rights reserved.
// </copyright>
//
// <createdOn>6/4/2017 6:57:13 PM</createdOn>
//
//---------------------------------------------------------------------------

using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Xaml;
using AppStudio.DataProviders.Rss;
using AproximacionUrbana.Sections;
using AproximacionUrbana.ViewModels;
using AppStudio.Uwp;

namespace AproximacionUrbana.Pages
{
    public sealed partial class NoticiasDeUrbanismoListPage : Page
    {
	    public ListViewModel ViewModel { get; set; }
        public NoticiasDeUrbanismoListPage()
        {
			ViewModel = ViewModelFactory.NewList(new NoticiasDeUrbanismoSection());

            this.InitializeComponent();
			commandBar.DataContext = ViewModel;
			NavigationCacheMode = NavigationCacheMode.Enabled;
        }

        protected override async void OnNavigatedTo(NavigationEventArgs e)
        {
			ShellPage.Current.ShellControl.SelectItem("e30d1d9d-601a-4f39-9ccd-eb5d68512af4");
			ShellPage.Current.ShellControl.SetCommandBar(commandBar);
			if (e.NavigationMode == NavigationMode.New)
            {			
				await this.ViewModel.LoadDataAsync();
                this.ScrollToTop();
			}			
            base.OnNavigatedTo(e);
        }

    }
}
