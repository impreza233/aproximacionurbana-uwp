namespace AproximacionUrbana.Layouts.List
{
    public sealed partial class CarouselMedium : ListLayoutBase
    {
        public CarouselMedium()
        {
            this.InitializeComponent();
        }
    }
}
