namespace AproximacionUrbana.Layouts.List
{
    public sealed partial class MenuSmall : ListLayoutBase
    {
        public MenuSmall() : base()
        {
            this.InitializeComponent();
        }
    }
}
