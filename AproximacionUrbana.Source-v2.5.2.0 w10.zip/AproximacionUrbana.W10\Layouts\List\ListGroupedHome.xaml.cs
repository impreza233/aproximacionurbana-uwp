using AppStudio.Uwp.Controls;
using Windows.UI.Xaml;

namespace AproximacionUrbana.Layouts.List
{
    public sealed partial class ListGroupedHome : ListLayoutBase
    {
        public ListGroupedHome()
        {
            this.InitializeComponent();
        }
    }
}
