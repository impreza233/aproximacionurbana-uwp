using System;
using System.Linq;
using System.Collections.Generic;
using System.Collections.ObjectModel;

using AppStudio.DataProviders;
using AppStudio.DataProviders.Core;

using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace AproximacionUrbana.Sections
{
    /// <summary>
    /// Implementation of the NoticiasDeTransporteSchemaParser class.
    /// </summary>
    public class NoticiasDeTransporteSchemaParser : IParser<NoticiasDeTransporteSchema>
    {	
        public IEnumerable<NoticiasDeTransporteSchema> Parse(string data)
        {
            if (string.IsNullOrEmpty(data))
            {
                return null;
            }

            var result = new Collection<NoticiasDeTransporteSchema>();
            JToken jtokenData = JsonConvert.DeserializeObject<JToken>(data);
            IEnumerable<JToken> elements = jtokenData.SelectToken("posts")?.Select(s => s);
            if (elements != null)
            {
                foreach (JToken item in elements)
                {
                    var itemResult = new NoticiasDeTransporteSchema();
					itemResult._id = item.SelectToken("ID")?.ToString();
					itemResult.title = item.SelectToken("title")?.ToString().DecodeHtml();
					itemResult.name = item.SelectToken("author.name")?.ToString().DecodeHtml();
					itemResult.content = item.SelectToken("content")?.ToString().DecodeHtml();
					itemResult.featured_image = item.SelectToken("featured_image")?.ToString();
                    result.Add(itemResult);
                }
            }
            return result;
        }
    }
}
